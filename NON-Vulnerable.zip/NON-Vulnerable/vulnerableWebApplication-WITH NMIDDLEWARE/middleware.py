import re
from flask import request
from datetime import datetime
import os
import json


sql_injection_patterns = [
    r"(\%27)|(\')|(\-\-)|(\%23)|(#)",
    r"(\bSELECT\b|\bUPDATE\b|\bINSERT\b|\bDELETE\b|\bDROP\b)",
    r"(\bOR\b|\bAND\b).*(=)",
]

command_injection_patterns = [
    r"(\bcat\b|\bls\b|\bwget\b|\bcurl\b|\bwhoami\b)",
    r"`.*?`"
]

http_header_injection_patterns = [
    r"(\r|\n|\r\n|\n\r)",
    r"(%0a|%0d|%0a%0d|%0d%0a)",
    r"[\r\n]"
]

def detect_injection(data, patterns):
    for key, value in data.items():
        for pattern in patterns:
            if re.search(pattern, value, re.IGNORECASE):
                return True, key, value
    return False, None, None

def log_attack(attack_type, key, value, ip, timestamp, full_payload):
    os.makedirs("logs", exist_ok=True)
    log_entry = (
        f"[{timestamp}] [IP: {ip}] [Type: {attack_type}]\n"
        f"Path: {request.path}\n"
        f"Parameter: {key}\n"
        f"Malicious Payload: {value}\n"
        f"Full Payload:\n{json.dumps(full_payload, indent=2)}\n"
        f"{'-'*60}\n"
    )
    with open("logs/attacks.log", "a") as f:
        f.write(log_entry)

def middleware():
    user_ip = request.remote_addr
    timestamp = datetime.now().isoformat()

   
    all_data = {
        "form": request.form.to_dict(),
        "query_params": request.args.to_dict(),
        "headers": dict(request.headers)
    }


    data_sources = [
        (all_data["form"], "Form"),
        (all_data["query_params"], "Query Params"),
        (all_data["headers"], "Headers")
    ]

    for data, label in data_sources:
        for pattern_list, attack_type in [
            (sql_injection_patterns, "SQL Injection"),
            (http_header_injection_patterns, "Header Injection")
        ]:
            found, key, value = detect_injection(data, pattern_list)
            if found:
                log_attack(f"{attack_type} ({label})", key, value, user_ip, timestamp, all_data)
                return f"Blocked: {attack_type} detected in {label}!", 403


    if request.method == "POST":
        form_data = all_data["form"]
        found, key, value = detect_injection(form_data, command_injection_patterns)
        if found:
            log_attack("Command Injection (Form)", key, value, user_ip, timestamp, all_data)
            return "Blocked: Command Injection detected in Form!", 403

    return None
